let snakeX = [];
let snakeY = [];
let bodyCount;
let up;
let down;
let left;
let right;
let foodX;
let foodY;
let formerX;
let formerY;
function setup() {
  createCanvas(500, 500);
  
  frameRate(10);
  
  snakeX = [];
  snakeY = [];

  bodyCount = 1;
  snakeX[bodyCount] = 20;
  snakeY[bodyCount] = 20;
  foodRandomize();
  
  print(bodyCount);
  
  up = false;
  down = false;
  left = false;
  right = false;
}

function draw() {
  background(30);
  
  snake();
  food();
  grid();
  formerX = snakeX[1];
  formerY = snakeY[1];
  movement();
  collisions();
  
  snakeX[0] = mouseX;
  snakeY[0] = mouseY;

  if (snakeX[bodyCount] == foodX && snakeY[bodyCount] == foodY) {
    foodRandomize();
    grow();
  }
  
  print(bodyCount);
}

function grid() {
  push();
    for (i=0; i<=width; i += 20) {
      line (i, 0, i, 500);
      line (0, i, 500, i);
    }
  pop();
}

function snake() {
  push();
    fill(255);
  
    for (let i = 1; i <= bodyCount; i++) {
      rect(snakeX[i], snakeY[i], 20, 20);
    }
  pop();
}

function keyPressed() {
  if (keyCode == 68 && !left) {
    up = false;
    down = false;
    right = true;
  } else if (keyCode == 65 && !right) {
    up = false;
    down = false;
    left = true;
  } else if (keyCode == 87 && !down) {
    up = true;
    left = false;
    right = false;
  } else if (keyCode == 83 && !up) {
    down = true;
    left = false;
    right = false;
  }
}

function movement() {
  for (let i = 1; i <= bodyCount; i++) {
    if (i < bodyCount) {
      snakeX[i] = snakeX[i+1];
      snakeY[i] = snakeY[i+1];
    }
      
    if (i == bodyCount) {
      if (right) {
        snakeX[i] += 20;
      }
      if (left) {
        snakeX[i] -= 20;
      }
      if (up) {
         snakeY[i] -= 20;
      }
      if (down) {
        snakeY[i] += 20;
      }
    }
  }
}

function foodRandomize() {
  foodX = (Math.floor(Math.random()*24)+1) * 20;
  foodY = (Math.floor(Math.random()*24)+1) * 20;
}

function food() {
  push();
    fill(255, 0, 0);
    rect(foodX, foodY, 20, 20);
  pop();
}

function grow() {
  bodyCount++;
  
  if (snakeX[bodyCount] == undefined && snakeY[bodyCount] == undefined) {
    snakeX[bodyCount] = snakeX[bodyCount-1];
    snakeY[bodyCount] = snakeY[bodyCount-1];
    
    for (let i = bodyCount-1; i>0; i--) {
      snakeX[i] = snakeX[i-1];
      snakeY[i] = snakeY[i-1];
    }
    
    snakeX[1] = formerX;
    snakeY[1] = formerY;
  }
}

function collisions() {
  if (snakeX[bodyCount] < 0 || snakeX[bodyCount] > width) {
    setup();
  }
  if (snakeY[bodyCount] < 0 || snakeY[bodyCount] > height) {
    setup();
  }
  
  for (let i = 1; i < bodyCount; i++) {
    if (snakeX[bodyCount] == snakeX[i] && snakeY[bodyCount] == snakeY[i]) {
      setup();
    }
  }
}