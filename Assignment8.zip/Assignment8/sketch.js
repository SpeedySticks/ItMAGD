let bgColor;
let bgTint;
let whiteNoise;
let cursor;
let asteroidx = [];
let asteroidy = [];
let horizontal = [];
let vertical = [];
let asteroidCount;
let mx;
let my;
let counter;

function preload() {
	whiteNoise = loadImage('assets/interference.png');
	cursor = loadImage('assets/target.png');
}

function setup() {
	createCanvas(400, 400);
	
	frameRate(10);

	bgColor = (175);
	bgTint = color(20, 100, 20, 150);
	asteroidCount = 21;
	counter = 0;
	
	//Asteroid Initial Locations
	for (let i = 0; i<asteroidCount; i++) {
		let random = Math.floor(Math.random()*4 + 1);
		if (random == 1) {
			asteroidx[i] = -25;
			asteroidy[i] = Math.floor(Math.random()*400 + 1);
		} 
		else if (random == 2) {
			asteroidx[i] = Math.floor(Math.random()*400 + 1);
			asteroidy[i] = -25;
		} 
		else if (random == 3) {
			asteroidx[i] = 425;
			asteroidy[i] = Math.floor(Math.random()*400 + 1);
		} 
		else if (random == 4) {
			asteroidx[i] = Math.floor(Math.random()*400 + 1);
			asteroidy[i] = 425;
		}
		
		if (asteroidx[i]>width/2) {
			horizontal[i] = false;
		} 
		else {
			horizontal[i] = true;
		}		
		if (asteroidy[i]>height/2) {
			vertical[i] = false;
		} 
		else {
			vertical[i] = true;
		}
	}
	
	asteroidx[20] = 450;
	asteroidy[20] = 450;
	horizontal[20] = true;
	vertical[20] = true;
}

function draw() {
	background(bgColor);
	fill(bgTint);
	rect(0, 0, 400, 400);
	
	mx = mouseX;
	my = mouseY;

	image(cursor, mx - 25, my - 25, 50, 50);
	
	asteroids();
	
	drawText();
	
	image(whiteNoise, 0, 0, 400, 400);
	
	taskCompleted();
}

function asteroids() {
	for (let i = 0; i<2; i++) {
		push();
		fill(70, 70, 70, 180);
		ellipse(asteroidx[i], asteroidy[i], 50, 50);
	
		pop();
		
		
		
		moveAsteroids(i);
	}
}

function moveAsteroids(i) {
	if (horizontal[i])
		asteroidx[i]+=10;
	else
		asteroidx[i]-=10;
	
	if (vertical[i])
		asteroidy[i]+=10;
	else
		asteroidy[i]-=10;
}

function mouseClicked() {
	for (let i = 0; i < 2; i++) {
		let radius = 25;
		let distance = dist(mx, my, asteroidx[i], asteroidy[i]);
		
		if (distance <= radius) {
			for (let k = i; k < asteroidCount; k++) {
				asteroidx[k] = asteroidx[k+1];
				asteroidy[k] = asteroidy[k+1];
				horizontal[k] = horizontal[k+1];
				vertical[k] = vertical[k+1];
			}
			asteroidx[asteroidCount] = [];
			asteroidy[asteroidCount] = [];
			horizontal[asteroidCount] = [];
			vertical[asteroidCount] = [];
			counter++;
		}
	}
}

function drawText() {
	push();
	textAlign(CENTER);
	stroke(255);
	noFill();
	textSize(22);
	textFont('Gotham');
	text('Total: '+counter, width/2-50, height-82, 100, 50);
	pop();
}

function taskCompleted() {
	if (counter == 20) {
		push();
		textAlign(CENTER);
		stroke(0);
		fill(0);
		textSize(50);
		textFont('Oswald');
		text('Task Completed', width/2, height/2);
		pop();
	}
}